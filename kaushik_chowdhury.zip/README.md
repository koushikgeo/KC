# Dr. Koushik Chowdhury — Free Academic Website

## Publish for free with GitHub Pages

1. Create/sign in to a GitHub account.
2. Create a **new public repository** named exactly:
   `YOURUSERNAME.github.io`
3. Upload `index.html` and `Koushik_CV_23.pdf` from this folder.
4. Open the repository's **Settings → Pages**.
5. Under the publishing/build option, choose the main branch/root folder and save.
6. Your website will appear at:
   `https://YOURUSERNAME.github.io`

## Before publishing
- Replace the placeholder ORCID, Google Scholar, ResearchGate and LinkedIn URLs in `index.html` with your exact profile URLs.
- You can replace the “KC” initials box with a professional photograph later.
- The CV and public contact details were taken from the supplied CV. Consider removing the phone number and residential address before making the site public.
